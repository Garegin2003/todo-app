import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  checkTodo,
  delTodo,
  editTodo,
  selectTodo,
  editConfirm,
} from '../../store/slices/todoSlice';
import { useParams, useNavigate } from 'react-router-dom';
import style from "./Uniq.module.css"

const Uniq = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const todo = useSelector(selectTodo);
  const todoItem = todo.find((item) => item.id === id);

  const handleEditToggle = (txtId) => {
    dispatch(
      editTodo({
        id,
        txtId,
      })
    );
  };

  const confirmHanadler = (txtId, txt) => {
    dispatch(
      editConfirm({
        id,
        txtId,
        txt,
      })
    );
  };

  const handleDelete = (txtId) => {
    dispatch(
      delTodo({
        id,
        txtId,
      })
    );
  };

  const handleCheckboxChange = (txtId) => {
    dispatch(
      checkTodo({
        id,
        txtId,
      })
    );
  };

  const handleBackClick = () => {
    navigate('/');
  };

  return (
    <div className={style.uniq}>
      <div className={style.back}>
      <button onClick={handleBackClick}>Back</button>
      <h1>
        {todoItem.date} ({todoItem.text.length})
      </h1></div>
      <div className={style.todos}>
      {todoItem.text.map((textItem) => (
        <div key={textItem.id}>
          <input
            onChange={() => handleCheckboxChange(textItem.id)}
            type="checkbox"
          />
          <h1
            contentEditable={textItem.edit}
            style={{ color: textItem.done ? 'grey' : '#4848db' }}
          >
            {textItem.txt}
          </h1>
          <p
            onClick={() =>
              textItem.edit
                ? confirmHanadler(textItem.id, textItem.txt)
                : handleEditToggle(textItem.id)
            }
          >
            {textItem.edit ? 'Confirm' : 'Edit'}
          </p>
          <p onClick={() => handleDelete(textItem.id)}>Delete</p>
        </div>
      ))}</div>
    </div>
  );
};

export default Uniq;
