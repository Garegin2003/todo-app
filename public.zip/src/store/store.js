import { configureStore } from '@reduxjs/toolkit';
import { todoReducer } from './slices/todoSlice';
import inputValidationMiddleware from './middleware/inputValidationMiddleware';

const store = configureStore({
  reducer: {
    todo: todoReducer,
  },
  middleware: (getDefaultMiddleware) => {
    return [...getDefaultMiddleware(), inputValidationMiddleware];
  },
});

export default store;
